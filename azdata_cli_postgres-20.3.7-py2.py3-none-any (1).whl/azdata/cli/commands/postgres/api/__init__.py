# ------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ------------------------------------------------------------------------------

from __future__ import absolute_import

# import apis into api package
from azdata.cli.commands.postgres.api.default_api import DefaultApi
