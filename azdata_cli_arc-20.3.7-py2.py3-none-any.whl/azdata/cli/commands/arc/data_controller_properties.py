# ------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ------------------------------------------------------------------------------

CONNECTION_MODE = 'connectionMode'
DISPLAY_NAME = 'displayName'
LOCATION = 'location'
RESOURCE_GROUP = 'resourceGroup'
SUBSCRIPTION = 'subscription'
